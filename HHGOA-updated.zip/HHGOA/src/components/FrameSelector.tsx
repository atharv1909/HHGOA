'use client';

import { PhotoFilterMode } from '@/lib/imageProcessor';
import styles from '@/styles/components/FrameSelector.module.css';

interface FrameSelectorProps {
  selectedFilter: PhotoFilterMode;
  onSelectFilter: (filter: PhotoFilterMode) => void;
}

const FILTERS: { id: PhotoFilterMode; label: string; icon: string }[] = [
  { id: 'natural', label: 'Natural', icon: '🌿' },
  { id: 'goa-sunset', label: 'Goa Sunset', icon: '🌅' },
  { id: 'riso-dither', label: 'Vintage Riso', icon: '🎨' },
];

export default function FrameSelector({
  selectedFilter,
  onSelectFilter,
}: FrameSelectorProps) {
  // There's a single, dedicated HH Goa 2026 Builder ID card — no frame-style
  // picker needed. If more card designs are ever added to FRAMES, a style
  // picker can be reintroduced here; for now we keep the UI to what the
  // product actually needs: the photo filter only.
  return (
    <div className={styles.selectorContainer}>
      <div className={styles.sectionGroup}>
        <span className={styles.sectionTitle}>PHOTO FILTER</span>
        <div className={styles.filterGrid}>
          {FILTERS.map((f) => (
            <button
              key={f.id}
              className={`${styles.filterBtn} ${
                selectedFilter === f.id ? styles.filterBtnSelected : ''
              }`}
              onClick={() => onSelectFilter(f.id)}
            >
              <span>{f.icon}</span>
              <span>{f.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
