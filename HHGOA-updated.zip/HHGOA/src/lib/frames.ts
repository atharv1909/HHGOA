// ═══════════════════════════════════════════════════════
// HH GOA 2026 — CARD ENGINE
// A single, dedicated Builder ID card design (matches the
// approved reference mockup 1:1). No frame-style picker —
// this IS the card.
// ═══════════════════════════════════════════════════════

export interface TextZone {
  x: number;
  y: number;
  maxWidth: number;
  fontSize: number;
  fontFamily: 'display' | 'mono';
  color: string;
  align?: CanvasTextAlign;
  weight?: string;
}

export interface BoxZone {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface FrameConfig {
  id: string;
  name: string;
  description: string;
  paletteMode: 'dark' | 'light';
  bgColor: string;
  photoZone: { x: number; y: number; width: number; height: number };
  /** The yellow ID box on the front of the card — QR + big builder-ID
   *  text + horizontal barcode all live INSIDE this rectangle, each in
   *  its own reserved sub-area, so they never overlap. */
  idBoxZone: BoxZone;
  /** QR code — left inside idBoxZone. */
  qrZone: { x: number; y: number; size: number };
  /** Horizontal barcode — right of the QR, below the big builder-ID text,
   *  still inside idBoxZone. */
  barcodeZone: BoxZone;
  textZones: {
    name: TextZone;
    stack: TextZone;
    /** Builder title / "class" — rendered inside the circular badge. */
    title: TextZone;
    /** Big, bold builder-ID readout inside the yellow box, next to the QR. */
    builderId: TextZone;
    timestamp: TextZone;
    /** Dedicated zone for the optional-socials row — must never share
     *  coordinates with builderId/timestamp, or they'll overlap. */
    socials: TextZone;
  };
  renderBackground?: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
  renderDecorations: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
  pfpPhotoZone: { x: number; y: number; width: number; height: number };
  renderPfpDecorations: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
}

// ── PALETTE (from the approved reference) ──
const GREEN_DARK = '#012119';
const GREEN_PANEL = '#004D34';
const PINK = '#FF2A8D';
const YELLOW = '#FFF78C';
const ORANGE = '#F5A623';
const CREAM = '#FBE6A2';

// ── SMALL DRAW HELPERS ──

function drawHindiBadge(ctx: CanvasRenderingContext2D, x: number, y: number) {
  // Small pink "गोवा" wordmark badge, sitting on a dark-green pill —
  // matches the reference's header treatment.
  const w = 190;
  const h = 78;
  ctx.save();
  ctx.fillStyle = GREEN_PANEL;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, 8);
  ctx.fill();
  ctx.fillStyle = PINK;
  ctx.font = '900 44px system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('गोवा', x + w / 2, y + h / 2 + 4);
  ctx.restore();
}

function drawPixelMark(ctx: CanvasRenderingContext2D, x: number, y: number) {
  // Small pink pixel-grid accent mark, top-left — purely decorative,
  // echoes the "8-bit signal" motif without literal cyberpunk cliché.
  const cell = 15;
  const gap = 5;
  const pattern = [
    [1, 0, 1, 0, 1],
    [0, 1, 1, 1, 0],
    [1, 1, 1, 1, 1],
    [0, 1, 1, 1, 0],
    [1, 0, 1, 0, 1],
  ];
  ctx.save();
  ctx.fillStyle = PINK;
  for (let r = 0; r < pattern.length; r++) {
    for (let c = 0; c < pattern[r].length; c++) {
      if (pattern[r][c]) {
        ctx.fillRect(x + c * (cell + gap), y + r * (cell + gap), cell, cell);
      }
    }
  }
  ctx.restore();
}

function drawLeafAccent(ctx: CanvasRenderingContext2D, x: number, y: number) {
  // Simple single-line leaf/frond accent, top-right corner.
  ctx.save();
  ctx.strokeStyle = 'rgba(251, 230, 162, 0.55)';
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  for (let i = 0; i < 5; i++) {
    const len = 70 - i * 8;
    const angle = (-30 - i * 14) * (Math.PI / 180);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(
      x + Math.cos(angle) * len * 0.6,
      y + Math.sin(angle) * len * 0.3,
      x + Math.cos(angle) * len,
      y + Math.sin(angle) * len
    );
    ctx.stroke();
  }
  ctx.restore();
}

function drawPalmSilhouette(ctx: CanvasRenderingContext2D, x: number, y: number, scale = 1) {
  // Simple palm-tree silhouette, bottom-left corner accent.
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.fillStyle = 'rgba(2, 26, 20, 0.5)';

  // trunk
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(-6, -60, 4, -120);
  ctx.lineTo(14, -120);
  ctx.quadraticCurveTo(6, -60, 12, 0);
  ctx.closePath();
  ctx.fill();

  // fronds
  const frondAngles = [-160, -130, -100, -70, -40, -10];
  for (const deg of frondAngles) {
    const a = (deg * Math.PI) / 180;
    ctx.beginPath();
    ctx.moveTo(8, -120);
    ctx.quadraticCurveTo(
      8 + Math.cos(a) * 45,
      -120 + Math.sin(a) * 45,
      8 + Math.cos(a) * 85,
      -120 + Math.sin(a) * 85
    );
    ctx.lineWidth = 8;
    ctx.strokeStyle = 'rgba(2, 26, 20, 0.5)';
    ctx.lineCap = 'round';
    ctx.stroke();
  }
  ctx.restore();
}

function drawSunRays(ctx: CanvasRenderingContext2D, cx: number, cy: number, innerR: number, outerR: number) {
  ctx.save();
  ctx.strokeStyle = YELLOW;
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  const rayCount = 20;
  for (let i = 0; i < rayCount; i++) {
    const a = (i / rayCount) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * innerR, cy + Math.sin(a) * innerR);
    ctx.lineTo(cx + Math.cos(a) * outerR, cy + Math.sin(a) * outerR);
    ctx.stroke();
  }
  ctx.restore();
}

function drawScallopedFrame(ctx: CanvasRenderingContext2D, box: BoxZone, bumpR = 14) {
  // Cream scalloped border ring around the photo, like a stamped
  // certificate edge — matches the reference photo frame exactly.
  ctx.save();
  ctx.fillStyle = CREAM;
  const { x, y, width, height } = box;

  const bumpsX = Math.round(width / (bumpR * 2));
  const stepX = width / bumpsX;
  const bumpsY = Math.round(height / (bumpR * 2));
  const stepY = height / bumpsY;

  // base plate
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, 4);
  ctx.fill();

  // scallops along all 4 edges
  for (let i = 0; i <= bumpsX; i++) {
    ctx.beginPath();
    ctx.arc(x + i * stepX, y, bumpR, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x + i * stepX, y + height, bumpR, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let i = 0; i <= bumpsY; i++) {
    ctx.beginPath();
    ctx.arc(x, y + i * stepY, bumpR, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x + width, y + i * stepY, bumpR, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawVine(ctx: CanvasRenderingContext2D, x: number, yTop: number, yBottom: number) {
  // Slim decorative vine with two small "flower" dots, right of the photo.
  ctx.save();
  ctx.strokeStyle = 'rgba(2, 26, 20, 0.45)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(x, yTop);
  const midY = (yTop + yBottom) / 2;
  ctx.quadraticCurveTo(x + 14, yTop + (midY - yTop) * 0.5, x, midY);
  ctx.quadraticCurveTo(x - 14, midY + (yBottom - midY) * 0.5, x, yBottom);
  ctx.stroke();
  ctx.restore();

  const flowerAt = (fy: number, r: number) => {
    ctx.save();
    ctx.fillStyle = PINK;
    ctx.beginPath();
    ctx.arc(x, fy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = GREEN_DARK;
    ctx.beginPath();
    ctx.arc(x, fy, r * 0.35, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };
  flowerAt(yTop + (yBottom - yTop) * 0.32, 9);
  flowerAt(yTop + (yBottom - yTop) * 0.7, 7);
}

function drawCornerAccent(ctx: CanvasRenderingContext2D, x: number, y: number, flip: boolean) {
  // Small curved white accent mark, echoing the box's corner detailing.
  ctx.save();
  ctx.strokeStyle = 'rgba(255,255,255,0.85)';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.beginPath();
  if (!flip) {
    ctx.arc(x + 22, y + 22, 18, Math.PI, Math.PI * 1.5);
  } else {
    ctx.arc(x - 22, y - 22, 18, 0, Math.PI * 0.5);
  }
  ctx.stroke();
  ctx.restore();
}

// ══════════════════════════════════════════════════════
// THE CARD: HACKERHOUSE GOA 2026 — BUILDER ID
// ══════════════════════════════════════════════════════
const HACKERHOUSE_GOA: FrameConfig = {
  id: 'hackerhouse-goa',
  name: 'HackerHouse Goa 2026',
  description: 'The official HH Goa 2026 Builder ID.',
  paletteMode: 'dark',
  bgColor: GREEN_DARK,

  // Square photo, centered — sun rays radiate from behind it.
  photoZone: { x: 290, y: 232, width: 500, height: 500 },

  // The yellow ID box: QR (left) + big builder-ID text (top-right) +
  // horizontal barcode (bottom-right) — three reserved sub-areas,
  // nothing overlaps.
  idBoxZone: { x: 60, y: 920, width: 960, height: 210 },
  qrZone: { x: 95, y: 955, size: 140 },
  barcodeZone: { x: 275, y: 1030, width: 705, height: 78 },

  textZones: {
    name: { x: 540, y: 762, maxWidth: 940, fontSize: 62, fontFamily: 'display', color: CREAM, align: 'center', weight: '900' },
    stack: { x: 540, y: 838, maxWidth: 900, fontSize: 26, fontFamily: 'mono', color: ORANGE, align: 'center', weight: '800' },
    // Rendered inside the circular "builder class" badge, right of the photo.
    title: { x: 935, y: 700, maxWidth: 150, fontSize: 16, fontFamily: 'mono', color: GREEN_DARK, align: 'center', weight: '800' },
    builderId: { x: 275, y: 955, maxWidth: 700, fontSize: 46, fontFamily: 'mono', color: GREEN_DARK, align: 'left', weight: '900' },
    timestamp: { x: 540, y: 1258, maxWidth: 500, fontSize: 13, fontFamily: 'mono', color: 'rgba(251,230,162,0.55)', align: 'center' },
    socials: { x: 540, y: 1160, maxWidth: 860, fontSize: 18, fontFamily: 'mono', color: CREAM, align: 'center', weight: '700' },
  },

  renderDecorations: (ctx, w, h) => {
    // Outer yellow border
    ctx.strokeStyle = YELLOW;
    ctx.lineWidth = 10;
    ctx.strokeRect(6, 6, w - 12, h - 12);

    // Decorative corner accents (kept small so they never reach into
    // the text/photo/box areas below).
    drawPixelMark(ctx, 55, 60);
    drawLeafAccent(ctx, w - 60, 55);
    drawPalmSilhouette(ctx, 60, h - 20, 0.85);

    // ── HEADER ──
    ctx.save();
    ctx.fillStyle = CREAM;
    ctx.font = '900 54px "Space Grotesk", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText('HACKERHOUSE', 70, 100);
    ctx.font = '40px system-ui, -apple-system, sans-serif';
    ctx.fillText('🏝️', 560, 100);
    ctx.restore();

    drawHindiBadge(ctx, 640, 45);

    ctx.save();
    ctx.fillStyle = ORANGE;
    ctx.font = '800 28px "JetBrains Mono", monospace';
    ctx.textAlign = 'left';
    ctx.fillText('GOA, INDIA · 28–31 OCT 2026', 70, 155);
    ctx.restore();

    // "2:47 PM STUDIO" tag — right side, above the photo.
    ctx.save();
    ctx.fillStyle = GREEN_PANEL;
    ctx.beginPath();
    ctx.roundRect(w - 190, 60, 130, 60, 6);
    ctx.fill();
    ctx.fillStyle = YELLOW;
    ctx.font = '900 18px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('2:47PM', w - 125, 88);
    ctx.font = '800 13px "JetBrains Mono", monospace';
    ctx.fillText('STUDIO', w - 125, 108);
    ctx.restore();

    // "#FrameInGoa" tag — right side, below the studio tag.
    ctx.save();
    const tagW = 190;
    const tagX = w - 60 - tagW;
    ctx.fillStyle = YELLOW;
    ctx.fillRect(tagX, 130, tagW * 0.4, 34);
    ctx.fillStyle = PINK;
    ctx.fillRect(tagX + tagW * 0.4, 130, tagW * 0.6, 34);
    ctx.fillStyle = GREEN_DARK;
    ctx.font = '800 15px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('#FrameInGoa', tagX + tagW / 2, 152);
    ctx.restore();

    // ── PHOTO SUN + SCALLOPED FRAME ──
    const photoZone = HACKERHOUSE_GOA.photoZone;
    const cx = photoZone.x + photoZone.width / 2;
    const cy = photoZone.y + photoZone.height / 2;
    drawSunRays(ctx, cx, cy, photoZone.width / 2 + 10, photoZone.width / 2 + 55);
    drawScallopedFrame(
      ctx,
      { x: photoZone.x - 18, y: photoZone.y - 18, width: photoZone.width + 36, height: photoZone.height + 36 },
      13
    );
    // (The photo itself is drawn between the background and this
    // decoration pass — this thin rim redraws on top so the photo
    // reads as neatly inset within the scalloped frame.)
    ctx.save();
    ctx.strokeStyle = GREEN_DARK;
    ctx.lineWidth = 6;
    ctx.strokeRect(photoZone.x, photoZone.y, photoZone.width, photoZone.height);
    ctx.restore();

    drawVine(ctx, 830, photoZone.y + 20, photoZone.y + photoZone.height - 20);

    // Builder-class circular badge, right of the photo.
    const badgeCx = 935;
    const badgeCy = 700;
    ctx.save();
    ctx.fillStyle = ORANGE;
    ctx.beginPath();
    ctx.arc(badgeCx, badgeCy, 78, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = GREEN_DARK;
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.fillStyle = GREEN_DARK;
    ctx.font = '800 13px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('BUILDER CLASS', badgeCx, badgeCy - 32);
    ctx.restore();

    // ── ID BOX (yellow) ──
    const box = HACKERHOUSE_GOA.idBoxZone;
    ctx.save();
    ctx.fillStyle = YELLOW;
    ctx.beginPath();
    ctx.roundRect(box.x, box.y, box.width, box.height, 26);
    ctx.fill();
    ctx.strokeStyle = GREEN_DARK;
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.restore();
    drawCornerAccent(ctx, box.x, box.y, false);
    drawCornerAccent(ctx, box.x + box.width, box.y + box.height, true);

    // White plate behind the QR so it stays crisp on the yellow field.
    ctx.save();
    const qz = HACKERHOUSE_GOA.qrZone;
    const pad = 10;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.roundRect(qz.x - pad, qz.y - pad, qz.size + pad * 2, qz.size + pad * 2, 8);
    ctx.fill();
    ctx.restore();

    // ── DATE PILL ──
    ctx.save();
    ctx.fillStyle = GREEN_PANEL;
    ctx.beginPath();
    ctx.roundRect(w - 300, 1165, 240, 46, 23);
    ctx.fill();
    ctx.fillStyle = YELLOW;
    ctx.font = '800 18px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('28–31 OCT 2026', w - 180, 1194);
    ctx.restore();

    // Footer tagline
    ctx.save();
    ctx.fillStyle = 'rgba(251,230,162,0.7)';
    ctx.font = '700 13px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('SHIP FROM PARADISE · 500 BUILDERS · #FRAMEINGOA', w / 2, h - 30);
    ctx.restore();
  },

  pfpPhotoZone: { x: 90, y: 90, width: 900, height: 900 },
  renderPfpDecorations: (ctx, w, h) => {
    ctx.strokeStyle = YELLOW;
    ctx.lineWidth = 14;
    ctx.strokeRect(7, 7, w - 14, h - 14);

    ctx.save();
    ctx.fillStyle = CREAM;
    ctx.font = '900 34px "Space Grotesk", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('HACKERHOUSE', 45, 55);
    ctx.fillStyle = PINK;
    ctx.font = '900 34px system-ui, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText('गोवा', w - 45, 55);
    ctx.restore();

    ctx.fillStyle = GREEN_PANEL;
    ctx.fillRect(0, h - 55, w, 55);
    ctx.fillStyle = YELLOW;
    ctx.font = '800 18px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('#FrameInGoa · 28-31 OCT 2026', w / 2, h - 22);
  },
};

export const FRAMES: FrameConfig[] = [HACKERHOUSE_GOA];

export function getFrame(id?: string): FrameConfig {
  if (!id) return HACKERHOUSE_GOA;
  return FRAMES.find((f) => f.id === id) || HACKERHOUSE_GOA;
}
